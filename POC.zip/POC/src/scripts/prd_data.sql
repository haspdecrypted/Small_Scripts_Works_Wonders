CREATE TABLE prd_data (
    item_id INT PRIMARY KEY,
    item_name VARCHAR(100),
    type VARCHAR(50),
    unit_cost DECIMAL(10,2),
    available_stock INT,
    vendor VARCHAR(100),
    unique_identifier CHAR(36)
);

INSERT INTO prd_data (item_id, item_name, type, unit_cost, available_stock, vendor, unique_identifier) VALUES
(1, 'Wireless Mouse', 'Electronics', 799.00, 120, 'GadgetSupply Co.', 'a1f3e9b0-5d99-4c7c-9e0b-6a8d4f4a1e01'),
(2, 'Bluetooth Speaker', 'Electronics', 1499.50, 80, 'SoundBlast Ltd.', 'b2e7c5a4-91f4-4db1-b44f-4f1a3d4ab9f2'),
(3, 'Organic Green Tea', 'Groceries', 299.00, 200, 'Herbal Essence', 'c3b11de2-12bc-4eb6-9003-d17a2a6c01a4');
