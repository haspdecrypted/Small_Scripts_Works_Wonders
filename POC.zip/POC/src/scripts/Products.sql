CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10,2),
    stock_quantity INT,
    supplier VARCHAR(100),
    uuid CHAR(36)
);

INSERT INTO Products (product_id, product_name, category, price, stock_quantity, supplier, uuid) VALUES
(1, 'Wireless Mouse', 'Electronics', 799.00, 120, 'GadgetSupply Co.', 'a1f3e9b0-5d99-4c7c-9e0b-6a8d4f4a1e01'),
(2, 'Bluetooth Speaker', 'Electronics', 1499.50, 80, 'SoundBlast Ltd.', 'b2e7c5a4-91f4-4db1-b44f-4f1a3d4ab9f2'),
(3, 'Organic Green Tea', 'Groceries', 299.00, 200, 'Herbal Essence', 'c3b11de2-12bc-4eb6-9003-d17a2a6c01a4'),
(4, 'Running Shoes', 'Footwear', 2599.99, 60, 'FitFeet Inc.', 'd4c1fe5f-3b3b-4f75-8a00-34f75bcecb8d'),
(5, 'Office Chair', 'Furniture', 4299.00, 30, 'ErgoComfort', 'e5d2afcc-2b1d-465b-9c6d-1fcd73a6d8a1'),
(6, 'LED Desk Lamp', 'Home Decor', 999.00, 100, 'BrightLite Traders', 'f6a31d24-92c5-4b0b-b2f0-d2159e574a0e'),
(7, 'Notebook - A5', 'Stationery', 49.00, 500, 'PaperHouse', 'a7bd021d-0177-43fa-9c4a-e9f47e5a1b0f'),
(8, 'Smartwatch', 'Electronics', 3999.99, 45, 'TechNova', 'b8c404ff-e2da-4d64-95d3-b3f9327a5a3c'),
(9, 'Backpack', 'Accessories', 1199.00, 70, 'TravelMate', 'c9d0fdc6-bb36-4223-b360-b3d12685d6a9'),
(10, 'Stainless Steel Bottle', 'Kitchenware', 599.00, 150, 'CoolHydro', 'daefffa7-0d2a-4aa2-8bcb-c8e4c2c10f1a');
