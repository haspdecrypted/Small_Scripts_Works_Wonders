package com.example.migration;

//import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DataMigrationUtil {

    private static final int BATCH_SIZE = 1000;
    private static final int THREAD_COUNT = 4;
    private static final int SHARD_SIZE = 25000;
    private static final String CONFIG_FILE = "migration.properties";

    public static void main(String[] args) {
        Properties config = loadConfig(CONFIG_FILE);
        if (config == null) {
            System.err.println("Failed to load configuration.");
            return;
        }

        ExecutorService executor = Executors.newFixedThreadPool(THREAD_COUNT);
        for (int i = 0; i < THREAD_COUNT; i++) {
            int minId = i * SHARD_SIZE + 1;
            int maxId = (i + 1) * SHARD_SIZE;
            executor.submit(() -> migrateShard(config, minId, maxId));
        }
        executor.shutdown();
    }

    public static void migrateShard(Properties config, int minId, int maxId) {
        try (
                Connection oracleConn = DriverManager.getConnection(
                        config.getProperty("oracle.url"),
                        config.getProperty("oracle.user"),
                        config.getProperty("oracle.password")
                );
                Connection mysqlConn = DriverManager.getConnection(
                        config.getProperty("mysql.url"),
                        config.getProperty("mysql.user"),
                        config.getProperty("mysql.password")
                )
        ) {
            mysqlConn.setAutoCommit(false);

            String fetchSQL = "SELECT item_id, item_name, type, unit_cost, available_stock, vendor, unique_identifier FROM prd_data WHERE item_id BETWEEN ? AND ?";
//            String insertSQL = "INSERT INTO Products (product_id, product_name, category, price, stock_quantity, supplier, uuid) VALUES (?, ?, ?, ?, ?, ?, ?)";
            String insertSQL = "INSERT INTO Products (product_id, product_name, category, price, stock_quantity, supplier, uuid) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE " +
                    "product_name = VALUES(product_name), " +
                    "category = VALUES(category), " +
                    "price = VALUES(price), " +
                    "stock_quantity = VALUES(stock_quantity), " +
                    "supplier = VALUES(supplier), " +
                    "uuid = VALUES(uuid)";

            try (
                    PreparedStatement fetchStmt = oracleConn.prepareStatement(fetchSQL);
                    PreparedStatement insertStmt = mysqlConn.prepareStatement(insertSQL)
            ) {
                fetchStmt.setInt(1, minId);
                fetchStmt.setInt(2, maxId);
                fetchStmt.setFetchSize(100); // streaming
                ResultSet rs = fetchStmt.executeQuery();

                int count = 0;
                while (rs.next()) {
                    try {
                        insertStmt.setInt(1, rs.getInt("item_id"));
                        insertStmt.setString(2, rs.getString("item_name"));
                        insertStmt.setString(3, rs.getString("type"));
                        insertStmt.setBigDecimal(4, rs.getBigDecimal("unit_cost"));
                        insertStmt.setInt(5, rs.getInt("available_stock"));
                        insertStmt.setString(6, rs.getString("vendor"));

                        String baseUuid = rs.getString("unique_identifier");
                        String randomSuffix = getRandomAlphaNumeric(6);
                        insertStmt.setString(7, baseUuid + "_" + randomSuffix);

                        insertStmt.addBatch();
                        count++;

                        if (count % BATCH_SIZE == 0) {
                            insertStmt.executeBatch();
                            mysqlConn.commit();
                            System.out.println(Thread.currentThread().getName() + " committed batch of " + count);
                        }
                    } catch (Exception rowEx) {
                        System.err.println("Row skipped due to error: " + rowEx.getMessage());
                    }
                }

                insertStmt.executeBatch();
                mysqlConn.commit();
                System.out.println(Thread.currentThread().getName() + " final commit completed. Total: " + count);
            }

        } catch (SQLException e) {
            System.err.println("Migration failed for shard " + minId + " to " + maxId + ": " + e.getMessage());
        }
    }

    private static String getRandomAlphaNumeric(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder result = new StringBuilder();
        Random rand = new Random();
        for (int i = 0; i < length; i++) {
            result.append(chars.charAt(rand.nextInt(chars.length())));
        }
        return result.toString();
    }

    private static Properties loadConfig(String filePath) {
        Properties props = new Properties();
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(filePath)) {
            if (is == null) {
                System.err.println("Failed to load config: " + filePath + " (file not found in classpath)");
                return null;
            }
            props.load(is);
            return props;
        } catch (IOException e) {
            System.err.println("Failed to load config: " + e.getMessage());
            return null;
        }
    }

}
